### Compare Versions
Compare two versions and returns whether it is greater or less than or equal to the other.

*Steps:*
1. Enter 2 versions in the command line arguments.
1. Returns whether version 1 is greater than or less than or equal to the other.

*Flow:*
1. main.py is to get the input from user using command line arguments.
1. calling compare_version method.
1. compare_version.py does all the validation and comparision.
    * It returns the result indicates Greater/Lesser/Equal.
1. unit_test.py does most of the test case scenarios.